Sistema de Gestão Escolar
Projeto final do modúlo Javascript do curso de Fullstack da IT Step Computer Academy.

Sobre
Sistema de gestão escolar com cadastro e consulta de alunos, professores e cursos

Objetivo do projeto
Atestar e solidificar o aprendizado adquirido durante o modúlo de Javascript, HTML5, CSS3 (Bootstrap).

Páginas:
-Home (navbar para acessar as telas do sistema)
-Cadastro
        -Alunos
        -Professores
        -Cursos (webdesing, back-end, marketing digital e etc)
-Consultas
        -Alunos
            -Todos os Alunos
            -Maiores de idade
            -Menores de idade
        -Professores
            -Todos os Professores
        -Turmas
            -Todas as Turmas
            -Turmas por Turno (manhã, tarde ou noite)
        -GERAL
            -Todas as Turmas
            -Todos os Professores
            -Todos os Alunos